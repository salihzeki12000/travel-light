=== Travel Light ===
Contributors: Machel Slack
Tags: travel, places of interest , maps
Donate link: http://example.com/
Requires at least: 4.0
Tested up to: 4.5
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Online Pre-Travel Planner by Unified Digital Media gives you a revolutionary online, pre-travel planning search engine, allowing your users to refine their search, to places of interest that closely match their prefered type of holiday or speacial interest. Places of interest like leisure activites, events , sporting toirnament, bars , night clubs and restaurants are just some of the creiterias high on travellers priority list. With Travel Light, travellers can plan their trip and book their itinerary with companies they love.

== Description ==
Online Pre-Travel Planner by Unified Digital Media gives you a revolutionary online, pre-travel planning search engine, allowing your users to refine their search, to places of interest that closely match their prefered type of holiday or speacial interest. Places of interest like leisure activites, events , sporting toirnament, bars , night clubs and restaurants are just some of the creiterias high on travellers priority list. With Travel Light, travellers can plan their trip and book their itinerary with companies they love.

 
Travel Light is creating a one-stop-planner for places traveller might like to visit while travelling. Using this WordPress Travel Planner plugin, you can add a places of interest filter and map on any page.

 
What Travel Life can offer:

A new and exciting offering for your travellers unlike anything else on the market a travel planner box to help your travellers find the places of interest they love and a brand new revenue channel to add value to your site and monetise traffic.
Ordered list:

1. Easy to use travel planner with itinerary
1. No predefined places of interest lists
1. Customised business groups

Unordered list:

* Google Map integration
* Showcase of images and photos for places of interest
* Lists place of interests\' information and redirects to place of interests\' website



== Installation ==
1. Upload \"test-plugin.php\" to the \"/wp-content/plugins/\" directory.
1. Activate the plugin through the \"Plugins\" menu in WordPress.
1. Place \"do_action( \'plugin_name_hook\' );\" in your templates.

== Frequently Asked Questions ==
= A question that someone might have =
An answer to that question.

= What about foo bar? =
Answer to foo bar dilemma.

== Screenshots ==
1. Travel Light allows your users to search for places they want to visit and refines their search to a particular interest.
2. Google Map integrations displays a user freindly pop up which lists all business information for a place of interest.
3. Users can easily add or remove places of interest to and from their itinerary and confirm their trip when they are checking out.

== Changelog ==
= 0.2 =
* A change since the previous version.
* Another change.

= 0.1 =
* Initial release.

== Upgrade Notice ==
= 0.2 =
Upgrade notices describe the reason a user should upgrade

= 0.1 =
This version fixes a security related bug. Upgrade immediately.